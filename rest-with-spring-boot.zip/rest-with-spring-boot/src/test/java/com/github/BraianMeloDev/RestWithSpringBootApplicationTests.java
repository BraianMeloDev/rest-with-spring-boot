package com.github.BraianMeloDev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestWithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
